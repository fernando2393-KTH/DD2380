public class main { 
    public static void main(String[] args) {
        HMM hmm = new HMM();
        hmm.read_hmm();
        // hmm.print_hmm();
        hmm.next_emission();
    } 
} 